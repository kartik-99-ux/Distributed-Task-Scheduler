/*The worker threads will continuously check for tasks in the TaskQueue. 
 * When a task is available, the worker will execute it. 
 * The tasks contain the logic (via Runnable), so the worker will call task.execute() to run the task's logic.
Each worker thread will run in an infinite loop, 
trying to fetch tasks from the queue and process them. 
If there are no tasks, the worker will wait until new tasks are added.*/
package com.project.taskscheduler;

public class Worker extends Thread {

    private final TaskQueue taskQueue;  // The shared task queue from which the worker will fetch tasks

    public Worker(TaskQueue taskQueue) {
        this.taskQueue = taskQueue;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Task task = taskQueue.getNextTask();  // Get the next task from the queue
                System.out.println(Thread.currentThread().getName() + " processing Task ID: " + task.getTaskId());
                
                // Simulate task processing
                Thread.sleep((long) (Math.random() * 1000));  // Simulating task processing time
                task.execute();  // Execute the task's logic
                System.out.println(Thread.currentThread().getName() + " completed Task ID: " + task.getTaskId());

            } catch (InterruptedException e) {
                System.err.println(Thread.currentThread().getName() + " interrupted.");
                break;  // Exit the loop if the thread is interrupted
            }
        }
    }
}
