package com.project.taskscheduler;

public class ProgressMonitor {

    private int totalTasks = 0;       // Total tasks added to the queue
    private int completedTasks = 0;   // Number of completed tasks

    // Method to increment the total number of tasks
    public synchronized void addTask() {
        totalTasks++;
    }

    // Method to mark a task as completed
    public synchronized void taskCompleted() {
        completedTasks++;
        printProgress();
    }

    // Prints the progress of tasks being completed
    private void printProgress() {
        int progress = (int) ((double) completedTasks / totalTasks * 100);
        System.out.println("Progress: " + completedTasks + "/" + totalTasks + " tasks completed (" + progress + "%)");
    }
}
