package com.project.taskscheduler;

public class Main {

    public static void main(String[] args) {
        // Create a TaskScheduler instance with 3 worker threads (you can adjust this number as needed)
        TaskScheduler scheduler = new TaskScheduler(3);

        // Start the task scheduler (this will start the TaskProducer and Worker threads)
        scheduler.start();
    }
}
