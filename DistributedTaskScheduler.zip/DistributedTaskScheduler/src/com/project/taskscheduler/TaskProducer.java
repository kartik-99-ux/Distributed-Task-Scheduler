/*The Task Producer will periodically create new tasks and add them to the TaskQueue.
* The producer will run in its own thread, generating tasks (with random descriptions and scheduling times) and adding them to the queue.*/

package com.project.taskscheduler;

public class TaskProducer extends Thread {

    private final TaskQueue taskQueue;

    public TaskProducer(TaskQueue taskQueue) {
        this.taskQueue = taskQueue;
    }

    @Override
    public void run() {
        while (true) {
            try {
                // Create a new task with a random description and scheduled time
                String description = "Task #" + (int) (Math.random() * 100);
                long scheduledTime = System.currentTimeMillis() + (long) (Math.random() * 5000);  // Random scheduled time in the future
                
                // Define the task logic (a simple example that just prints a message)
                Runnable taskLogic = () -> System.out.println("Executing task logic for: " + description);

                // Create the task
                Task task = new Task(description, taskLogic, scheduledTime);

                // Add the task to the queue
                taskQueue.addTask(task);
                System.out.println("Added Task ID: " + task.getTaskId() + " with description: " + description);

                // Sleep for a random period before adding the next task
                Thread.sleep(2000);  // Add a new task every 2 seconds

            } catch (InterruptedException e) {
                System.err.println("TaskProducer interrupted.");
                break;  // Exit the loop if the producer is interrupted
            }
        }
    }
}

