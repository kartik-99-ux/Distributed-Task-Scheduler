package com.project.taskscheduler;

import java.util.PriorityQueue;

public class TaskQueue {

    private final PriorityQueue<Task> queue = new PriorityQueue<>((t1, t2) -> Long.compare(t1.getScheduledTime(), t2.getScheduledTime()));

    // Synchronized method to add a task to the queue
    public synchronized void addTask(Task task) {
        queue.add(task);
        notify();  // Notify waiting worker threads that a task has been added
    }

    // Synchronized method to retrieve and remove the next task from the queue
    public synchronized Task getNextTask() throws InterruptedException {
        while (queue.isEmpty()) {
            wait();  // Wait until a task is available
        }
        return queue.poll();  // Retrieve and remove the highest priority task (based on scheduled time)
    }

    // Synchronized method to get the size of the task queue
    public synchronized int getSize() {
        return queue.size();
    }
}
