/*The TaskScheduler will manage the initialization and execution of the task producer and worker threads. It will:

Start the task producer to generate tasks.
Start multiple worker threads that will process the tasks.*/

package com.project.taskscheduler;

public class TaskScheduler {

    private final TaskQueue taskQueue = new TaskQueue();  // Shared task queue
    private final int workerCount;  // Number of worker threads

    // Constructor to initialize the number of worker threads
    public TaskScheduler(int workerCount) {
        this.workerCount = workerCount;
    }

    // Method to start the task scheduler (which starts the producer and worker threads)
    public void start() {
        // Start the task producer thread
        TaskProducer producer = new TaskProducer(taskQueue);
        producer.start();

        // Start worker threads
        for (int i = 0; i < workerCount; i++) {
            Worker worker = new Worker(taskQueue);
            worker.setName("Worker-" + (i + 1));  // Set the name of the worker thread
            worker.start();
        }
    }
}
