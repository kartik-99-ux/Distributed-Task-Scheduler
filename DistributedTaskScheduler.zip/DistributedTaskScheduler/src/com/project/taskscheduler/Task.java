package com.project.taskscheduler;

import java.util.UUID;

public class Task {

    private final String taskId;  // Unique ID for the task
    private final String description; // Description of the task
    private final Runnable taskLogic; // The actual logic to be executed
    private final long scheduledTime; // The time at which the task should execute (in milliseconds)

    // Constructor
    public Task(String description, Runnable taskLogic, long scheduledTime) {
        this.taskId = UUID.randomUUID().toString(); // Generate a unique ID
        this.description = description;
        this.taskLogic = taskLogic;
        this.scheduledTime = scheduledTime;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getDescription() {
        return description;
    }

    public Runnable getTaskLogic() {
        return taskLogic;
    }

    public long getScheduledTime() {
        return scheduledTime;
    }

    // Execute the task
    public void execute() {
        System.out.println("Executing Task: " + taskId + " - " + description);
        taskLogic.run();
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId='" + taskId + '\'' +
                ", description='" + description + '\'' +
                ", scheduledTime=" + scheduledTime +
                '}';
    }
}
